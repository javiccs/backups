function validatePhone(phoneNumber) {
    var reg=/^([0-9]{7})$/i;
    if (reg.test(phoneNumber)) return true;
    else return false;
    }
function validateEmail(email) {
    regExp = /^([a-zA-Z0-9_+\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (regExp.test(email)){
        return(true);
    }
    return(false);
}

function validateText(text) {
    var reg = /^([a-z ñáéíóú]{2,60})$/i;
    if (reg.test(text)) return true;
    else return false;
}

function validateSticker(text) {
    var reg = /^([a-z0-9]{2,60})$/i;
    if (reg.test(text)) return true;
    else return false;
}

function validateDocument(id) {
    var reg=/^([0-9]{6,8})$/i;
    if (reg.test(id)) return true;
    else return false;
}

function validateCard(number) {
    var reg=/^([0-9]{20})$/i;
    if (reg.test(number)) return true;
    else return false;
}
function validateCvc(number) {
    var reg=/^([0-9]{3})$/i;
    if (reg.test(number)) return true;
    else return false;
}

