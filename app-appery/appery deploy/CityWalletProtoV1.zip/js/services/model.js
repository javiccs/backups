/**
 * Data models
 */
Apperyio.Entity = new Apperyio.EntityFactory({
    "infiniteList": {
        "type": "object",
        "properties": {
            "limit": {
                "type": "string"
            },
            "skip": {
                "type": "string"
            },
            "noMoreItems": {
                "type": "string"
            }
        }
    },
    "Number": {
        "type": "number"
    },
    "visit": {
        "type": "object",
        "properties": {
            "id": {
                "type": "string"
            },
            "stickerId": {
                "type": "string"
            },
            "stickerLabel": {
                "type": "string"
            },
            "merchantName": {
                "type": "string"
            },
            "merchantIcon": {
                "type": "string"
            },
            "merchantId": {
                "type": "string"
            },
            "error": {
                "type": "string"
            }
        }
    },
    "user": {
        "type": "object",
        "properties": {
            "id": {
                "type": "string"
            },
            "documentId": {
                "type": "string"
            },
            "balance": {
                "type": "string"
            },
            "icon": {
                "type": "string"
            },
            "lastName": {
                "type": "string"
            },
            "mobile": {
                "type": "string"
            },
            "email": {
                "type": "string"
            },
            "status": {
                "type": "string"
            },
            "name": {
                "type": "string"
            }
        }
    },
    "visits": {
        "type": "array",
        "items": {
            "type": "visit"
        }
    },
    "Boolean": {
        "type": "boolean"
    },
    "String": {
        "type": "string"
    },
    "payment": {
        "type": "object",
        "properties": {
            "respondeCode": {
                "type": "string"
            },
            "bankMessage": {
                "type": "string"
            },
            "voucher": {
                "type": "string"
            }
        }
    },
    "payments": {
        "type": "array",
        "items": {
            "type": "payment"
        }
    },
    "error": {
        "type": "object",
        "properties": {
            "msg": {
                "type": "string"
            },
            "code": {
                "type": "string"
            }
        }
    },
    "sticker": {
        "type": "object",
        "properties": {
            "date": {
                "type": "string"
            },
            "status": {
                "type": "string"
            },
            "label": {
                "type": "string"
            },
            "id": {
                "type": "string"
            },
            "tagId": {
                "type": "string"
            }
        }
    },
    "stickers": {
        "type": "array",
        "items": {
            "type": "sticker"
        }
    },
    "transactions": {
        "type": "array",
        "items": {
            "type": "transaction"
        }
    },
    "transaction": {
        "type": "object",
        "properties": {
            "id": {
                "type": "string"
            },
            "date": {
                "type": "string"
            },
            "pos": {
                "type": "string"
            },
            "type": {
                "type": "string"
            }
        }
    }
});
Apperyio.getModel = Apperyio.Entity.get.bind(Apperyio.Entity);

/**
 * Data storage
 */
Apperyio.storage = {

    "user": new $a.SessionStorage("user", "user"),

    "stickers": new $a.SessionStorage("stickers", "stickers"),

    "error": new $a.SessionStorage("error", "error"),

    "visitInfinite": new $a.SessionStorage("visitInfinite", "infiniteList"),

    "sessionToken": new $a.LocalStorage("sessionToken", "String"),

    "limit": new $a.SessionStorage("limit", "String"),

    "skip": new $a.SessionStorage("skip", "String"),

    "errorAux": new $a.SessionStorage("errorAux", "error"),

    "visits": new $a.SessionStorage("visits", "visits"),

    "payments": new $a.SessionStorage("payments", "payments")
};