/*
 * Services
 */

var RESTLogin = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/login',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415174',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTGetStickers = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/getstickers',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415174',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTForgotPassword = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/forgotpassword',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415174',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTCreateAccount = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/createaccount',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415175',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTAddSticker = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/addsticker',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415175',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTSetPassword = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/setpassword',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415175',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTGetVisits = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/getvisits',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415175',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTUpdateSticker = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/updatesticker',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415175',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTAddFunds = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/instapago/createpayment',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415176',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {
            "sessionToken": "f9c7a447-ff22-44bc-991d-65157f785a0a"
        },
        "parameters": {},
        "body": null
    }
});

var RESTGetUser = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/getuser',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415176',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTLogout = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://caracas-dev.citywallet.net:8080/citywallet/services/v1/logout',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460466415176',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});