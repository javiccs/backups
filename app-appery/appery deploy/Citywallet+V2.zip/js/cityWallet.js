function formatDateMY(date){
	var today=new Date(date);
    if((today.getMonth()+1)<10){
		month="0"+(today.getMonth()+1);
	}
	else{
	month=(today.getMonth()+1);
	}
    return(month+today.getFullYear());
}

