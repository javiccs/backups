function errorMessage(code){

	switch (code) {     
      case 1:
        Apperyio('labelPopupError').text('Los campos no pueden estar vacíos');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		break;             
      case 2:
        Apperyio('labelPopupError').text('Parámetros Inválidos');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		break;            
      case 3:
		Apperyio('labelPopupError').text('Usuario no registrado');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		Appery("inputEmail").css("box-shadow", "0 0 12px red");
		break;
      case 4:
		Apperyio('labelPopupError').text('Error genérico 4');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		Appery("inputUser").css("box-shadow", "0 0 12px red");
        break;  
      case 6:
		Apperyio('labelPopupError').text('El usuario ya existe en el sistema');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		Appery("inputEmail").css("box-shadow", "0 0 12px red");            
		break; 
      case 7:  
        Apperyio('labelPopupError').text('Correo inválido');
        Appery("inputUser").css("box-shadow", "0 0 12px red");
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		break;
      case 8:
        Apperyio('labelPopupError').text('Contraseña inválida');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputPassword").css("box-shadow", "0 0 12px red");
        break;
      case 9:
        Apperyio('labelPopupError').text('Cuenta inválida');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputUser").css("box-shadow", "0 0 12px red");
        break;
      case 10:
        Apperyio('labelPopupError').text('Código inválido');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		break;            
      case 11:
        Apperyio('labelPopupError').text('Las contraseñas no coinciden');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        getStickers.execute();
        Appery("inputNewPassword").css("box-shadow", "0 0 12px red");
		Appery("inputPassword").css("box-shadow", "0 0 12px red");
        break; 
      case 12:  
        Apperyio('labelPopupError').text('Error genérico 12');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		Appery("inputUser").css("box-shadow", "0 0 12px red");
        break;  
      case 13:
		Apperyio('labelPopupError').text('Usuario no registrado');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		Appery("inputUser").css("box-shadow", "0 0 12px red");
        break;           
      case 15:
		Apperyio('labelPopupError').text('La confirmación de contraseña no coincide con la nueva contraseña');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputNewPassword").css("box-shadow", "0 0 12px red");
        Appery("inputConfirmationPassword").css("box-shadow", "0 0 12px red");    
		break;
      case 16:
        Apperyio('labelPopupError').text('La contraseña tiene que ser mayor o igual a 5 caracteres');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		Appery("inputNewPassword").css("box-shadow", "0 0 12px red");
        break;
      case 31:
		Apperyio('labelPopupError').text('Sticker Inválido');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        break;            
      case "104":
		return("");
      case "105":
		return("");
      case "106":
		return("");
      case 200:
		Apperyio('labelPopupError').text('Inicie sesión nuevamente ');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} ); 
        Apperyio.navigateTo('cityWallet',{});    
		break;
      case 500:
		$("input").css("box-shadow", "none");
        Apperyio('labelPopupError').text('El nombre posee un carácter inválido');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputName").css("box-shadow", "0 0 12px red");
        Apperyio('inputName').val(""); 
		break;  
      case 501:
        $("input").css("box-shadow", "none");           
        Apperyio('labelPopupError').text('El apellido posee un carácter inválido');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputLastName").css("box-shadow", "0 0 12px red");
        Apperyio('inputLastName').val("");
		break;         
      case 502:
        $("input").css("box-shadow", "none");
        Apperyio('labelPopupError').text('Cédula inválida');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputDocumentId").css("box-shadow", "0 0 12px red"); 
        Apperyio('inputDocumentId').val("");
		break;  
      case 503:
        $("input").css("box-shadow", "none");           
        Apperyio('labelPopupError').text('Correo inválido'); 
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputEmail").css("box-shadow", "0 0 12px red");
        Apperyio('inputEmail').val('');
		break;  
      case 504:
        Apperyio('labelPopupError').text('Número telefónico inválido');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputMobile").css("box-shadow", "0 0 12px red");
        Apperyio('inputMobile').val('');
		break;    
      case 505:
        $("input").css("box-shadow", "none");
        Apperyio('labelPopupError').text('El código posee un carácter inválido');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputStickerId").css("box-shadow", "0 0 12px red");
        Apperyio('inputStickerId').val("");
		break;   
      case 506:
        $("input").css("box-shadow", "none");
        Apperyio('labelPopupError').text('La tarjeta es inválida ');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputCard").css("box-shadow", "0 0 12px red");
        Apperyio('inputCard').val("");
		break; 
      case 507:
        $("input").css("box-shadow", "none");
        Apperyio('labelPopupError').text('El código CVC es inválido ');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        Appery("inputStickerId").css("box-shadow", "0 0 12px red");
        Apperyio('inputStickerId').val("");
		break;             
      case 997:   
		Apperyio('labelPopupError').text('Ha ocurrido un error al enviar su clave. Inténtelo nuevamente');
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
		break;
      case 999:
        Apperyio('labelPopupError').text('Ha ocurrido un error, inténtelo nuevamente');
        Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        break;
      default:
		Apperyio('labelPopupError').text('Ha ocurrido un error inesperado código:'+code);
		Appery( "popupError" ).popup( "open", {transition:"slideup"} );
        break;
            
    }
}