function ToggleEvent(element) {
    
function notify() {
  alert( "clicked" );
}
    
$("element").on( "click", notify);


}