/*
 * Services
 */

var RESTTransfer = new Apperyio.RestService({
    'url': 'http://movistar.citywallet.net/transfer.php',
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});

var RESTBalance_clone_1 = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://movistar.citywallet.net/getBalance.php',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460467222638',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {
            "id": "1"
        },
        "body": null
    }
});

var RESTBalance = new Apperyio.RestService({
    'url': 'https://api.appery.io/rest/1/proxy/tunnel',
    'proxyHeaders': {
        'appery-proxy-url': 'http://movistar.citywallet.net/getBalance.php',
        'appery-transformation': 'checkTunnel',
        'appery-key': '1460467222638',
        'appery-rest': '8b351336-e8a8-45e2-9a31-bae8e697cf4b'
    },
    'dataType': 'json',
    'type': 'get',

    'defaultRequest': {
        "headers": {},
        "parameters": {},
        "body": null
    }
});