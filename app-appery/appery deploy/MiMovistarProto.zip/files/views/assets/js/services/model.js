/**
 * Data models
 */
Apperyio.Entity = new Apperyio.EntityFactory({
    "Number": {
        "type": "number"
    },
    "Boolean": {
        "type": "boolean"
    },
    "String": {
        "type": "string"
    }
});
Apperyio.getModel = Apperyio.Entity.get.bind(Apperyio.Entity);

/**
 * Data storage
 */
Apperyio.storage = {

    "show": new $a.SessionStorage("show", "Number"),

    "menu": new $a.SessionStorage("menu", "Number"),

    "cel": new $a.LocalStorage("cel", "String"),

    "client": new $a.SessionStorage("client", "String"),

    "fund": new $a.SessionStorage("fund", "String"),

    "data": new $a.SessionStorage("data", "String")
};